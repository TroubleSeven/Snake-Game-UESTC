Page({
        data:{
            imgs:[
              "../../pages/images/Welcome1.jpg",//背景图片
               "../../pages/images/Welcome2.jpg",
               "../../pages/images/Welcome3.jpg"
           ],  
        },
//跳转页面,url为跳转后页面
        start(){
             wx.navigateTo({
               url: '../../pages/degree/degree'
            })
            //  wx.redirectTo({ url: '../index/index' })
        },
     })