//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
  },
    start(e){
      var id = e.currentTarget.id;
      var app = getApp();
      app.requestDetailid = id;
      console.log(id);
            wx.navigateTo({
            url: '../../pages/snake/snake'
        })
        //  wx.redirectTo({ url: '../index/index' })
    }
})
